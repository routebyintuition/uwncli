# uwncli
Unikum Wunderbar Nutanix CLI

Nutanix CLI API driven application allowing capabilities to administer Nutanix clusters via remote hosts.